import pygame
import sys
import random

# Initialize pygame
pygame.init()

# Screen dimensions
WIDTH, HEIGHT = 1024, 768
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Dinosaur Game")

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GROUND_COLOR = (150, 150, 150)




# Clock and font
clock = pygame.time.Clock()
font = pygame.font.Font(None, 36)



# Game variables
gravity = 0.5
jump_power = -18
ground_height = 50
game_active = False
score = 0
high_score = 0
current_background_index = 0
score_threshold = 100  # Score after which the background changes




# Load assets
dino_img = [
    pygame.image.load(f"dino/{i}.png") for i in range(1, 22)
]

dino_img = [pygame.transform.scale(frame, (250, 200)) for frame in dino_img]  # Dino size adjusted



cactus_images = [
    pygame.image.load("cactus/cac1.png"),
    pygame.image.load("cactus/cac2.png"),
    pygame.image.load("cactus/cac3.png"),
]
cactus_images = [pygame.transform.scale(img, (120, 100)) for img in cactus_images]  # Normalized cactus size






background_images = [
    pygame.image.load("background.jpg"),
    pygame.image.load("background2.png"),
    pygame.image.load("background3.jpg"),
]
background_images = [
    pygame.transform.scale(img, (WIDTH, HEIGHT)) for img in background_images
]





# Dino variables
dino_rect = pygame.Rect(100, HEIGHT - ground_height - 100, 100, 100)  # Dino collision rect
dino_vel = 0
on_ground = True
dino_img_index = 0
dino_animation_speed = 0.1
dino_animation_timer = 0





# Cactus variables
obstacles = []
obstacle_timer = 0
obstacle_interval = 1500  # Time between obstacles in milliseconds




# Background variables
background_x = 0
background_speed = 3





# Road variables
road_y = HEIGHT - ground_height
road_height = 5  # Thickness of the road





def start_menu():
    """Display the start menu with options to start or quit."""
    options = ['Start Game', 'Quit Game']
    selected_option = 0
    menu_running = True

    while menu_running:
        screen.fill(BLACK)
        screen.blit(background_images[current_background_index], (0, 0))

        # Display menu options
        for i, option in enumerate(options):
            color = WHITE if i == selected_option else (150, 150, 150)
            option_text = font.render(option, True, color)
            screen.blit(option_text, (WIDTH // 2 - option_text.get_width() // 2, HEIGHT // 2 - 100 + i * 60))

        pygame.display.update()

        # Handle user input
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_DOWN:
                    selected_option = (selected_option + 1) % len(options)
                if event.key == pygame.K_UP:
                    selected_option = (selected_option - 1) % len(options)
                if event.key == pygame.K_RETURN:
                    if selected_option == 0:  # Start Game
                        reset_game()
                        return
                    elif selected_option == 1:  # Quit Game
                        pygame.quit()
                        sys.exit()


def reset_game():
    """Reset game variables."""
    global dino_vel, obstacles, score, game_active, current_background_index
    dino_vel = 0
    obstacles = []
    score = 0
    current_background_index = 0
    game_active = True


def game_over_menu():
    """Display the game-over menu with score details."""
    global game_active
    menu_running = True
    while menu_running:
        screen.fill(BLACK)

        # Display scores
        score_text = font.render(f"Your Score: {score}", True, WHITE)
        high_score_text = font.render(f"High Score: {high_score}", True, WHITE)
        restart_text = font.render("Press ENTER to Restart", True, WHITE)

        screen.blit(score_text, (WIDTH // 2 - score_text.get_width() // 2, HEIGHT // 2 - 100))
        screen.blit(high_score_text, (WIDTH // 2 - high_score_text.get_width() // 2, HEIGHT // 2 - 50))
        screen.blit(restart_text, (WIDTH // 2 - restart_text.get_width() // 2, HEIGHT // 2 + 50))

        pygame.display.update()

        # Handle user input
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    reset_game()
                    menu_running = False


# Cactus variables
obstacles = []  # List of dictionaries: {"rect": Rect, "scored": False}
obstacle_timer = 0
obstacle_interval = 1500  # Time between obstacles in milliseconds

# Game loop
start_menu()

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.KEYDOWN and game_active:
            if event.key == pygame.K_SPACE and on_ground:
                dino_vel = jump_power
                on_ground = False

    if game_active:
        # Background scrolling
        background_x -= background_speed
        if background_x <= -WIDTH:
            background_x = 0
        screen.blit(background_images[current_background_index], (background_x, 0))
        screen.blit(background_images[current_background_index], (background_x + WIDTH, 0))

        # Draw road
        pygame.draw.rect(screen, GROUND_COLOR, (0, road_y, WIDTH, road_height))

        # Change background based on score
        if score // score_threshold > current_background_index:
            current_background_index = min(current_background_index + 1, len(background_images) - 1)

        # Dino physics
        dino_vel += gravity
        dino_rect.y += dino_vel
        if dino_rect.bottom >= HEIGHT - ground_height:
            dino_rect.bottom = HEIGHT - ground_height
            on_ground = True

        # Obstacle movement and spawning
        obstacle_timer += clock.get_time()
        if obstacle_timer > obstacle_interval:
            obstacle_timer = 0
            obstacle_interval = random.randint(1200, 2000)
            random_cactus = random.choice(cactus_images)
            obstacle_rect = random_cactus.get_rect(midbottom=(WIDTH + 50, road_y))
            obstacles.append({"rect": obstacle_rect, "scored": False})

        for obstacle in obstacles[:]:
            obstacle["rect"].x -= 6
            if obstacle["rect"].right < 0:
                obstacles.remove(obstacle)
            screen.blit(random_cactus, obstacle["rect"])

        # Collision detection and scoring
        for obstacle in obstacles:
            if dino_rect.colliderect(obstacle["rect"]):
                if score > high_score:
                    high_score = score
                game_active = False
            elif obstacle["rect"].right < dino_rect.left and not obstacle["scored"]:  # Passed cactus without collision
                obstacle["scored"] = True  # Mark as scored
                score += 10  # Increase score

        # Update animation timer and index
        dino_animation_timer += dino_animation_speed
        if dino_animation_timer >= 1:
            dino_animation_timer = 0
            dino_img_index = (dino_img_index + 1) % len(dino_img)

        # Get the current frame
        current_frame = dino_img[dino_img_index]
        screen.blit(current_frame, (dino_rect.x - 50, dino_rect.y - 60))  # Adjusted for display size

        # Display score
        score_text = font.render(f"Score: {score}", True, WHITE)
        screen.blit(score_text, (10, 10))

    else:
        game_over_menu()

    pygame.display.flip()
    clock.tick(60)
